
// 드롭다운 메뉴창
$('.nav>li:not(.home)').on('mouseenter',function(){
	$('#menu-bg').stop().slideDown();	
	$('.sublist').stop().slideDown();
});
$('#menu-bg').on('mouseleave',function(){
	$(this).stop().slideUp();	
	$('.sublist').stop().slideUp();
});

// 	숫자 증가 카운트
// 가맹점 현황
let tst = 123;
$({ val : 0 }).animate({ val : tst }, {
  duration: 20000,
  step: function() {
    var num = numberWithCommas(Math.floor(this.val)); // 소수점 이하 버림
    $(".total-store").text(num);
  },
  complete: function() {
    var num = numberWithCommas(Math.floor(this.val));
    $(".total-store").text(num);
  }
});

// 총 매출
let tsal = 51326793234;
$({ val : 0 }).animate({ val : tsal }, {
  duration: 30000,
  step: function() {
    var num = numberWithCommas(Math.floor(this.val));
    $(".total-sale").text(num);
  },
  complete: function() {
    var num = numberWithCommas(Math.floor(this.val));
    $(".total-sale").text(num);
  }
});

// 총 임직원
let tmg = 6;
$({ val : 0 }).animate({ val : tmg }, {
  duration: 20000,
  step: function() {
    var num = numberWithCommas(Math.floor(this.val));
    $(".total-maneger").text(num);
  },
  complete: function() {
    var num = numberWithCommas(Math.floor(this.val));
    $(".total-maneger").text(num);
  }
});

// 함께하는 회원
let tmb = 201;
$({ val : 0 }).animate({ val : tmb }, {
  duration: 20000,
  step: function() {
    var num = numberWithCommas(Math.floor(this.val));
    $(".total-member").text(num);
  },
  complete: function() { // text(num)사라진 후 수행할 작업
    var num = numberWithCommas(Math.floor(this.val));
    $(".total-member").text(num);
  }
});

// 정규식 사용 -> 천단위를 끊어 , 삽입
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

////////////////////////////////////////////////////////////////////////

// 관리자메인화면 하단 슬라이드
$('.page-btn').click(function(){
    let $clicked = $(this);
    let $slider = $(this).closest('.slider');
    
    let index = $(this).index();
    let isLeft = index == 0;    
    
    let $current = $slider.find(' > .slides > .bn.active');
    let $post;
    
    if ( isLeft ){
        $post = $current.prev();
    }
    else {
        $post = $current.next();
    }    
    
    if ( $post.length == 0 ){
        if ( isLeft ){
            $post = $slider.find(' > .slides >.bn:last-child');
        }
        else {
            $post = $slider.find(' > .slides >.bn:first-child');
        }
    }
    
    $current.removeClass('active');
    $post.addClass('active');
    
    updateCurrentPageNumber();
});

setInterval(function(){
    $('.next-btn').click();
	}, 8000);

// 슬라이더 페이지 번호 지정
function pageNumber__Init(){
    // 전채 배너 페이지 갯수 세팅해서 .slider 에 'data-slide-total' 넣기
    var totalSlideNo = $('.bn').length;
    //console.log(totalSlideNo);
    
    $('.slider').attr('data-slide-total', totalSlideNo);
    
    // 각 배너 페이지 번호 매기기
    $('.bn').each(function(index, node){
        $(node).attr('data-slide-no', index + 1);
    });
};
pageNumber__Init();

// 슬라이더 이동시 페이지 번호 변경
function updateCurrentPageNumber(){
    var totalSlideNo = $('.slider').attr('data-slide-total');
    var currentSlideNo = $('.bn.active').attr('data-slide-no');
    
    $('.total-slide-no').html(totalSlideNo);
    $('.current-slide-no').html(currentSlideNo);
};
updateCurrentPageNumber();
